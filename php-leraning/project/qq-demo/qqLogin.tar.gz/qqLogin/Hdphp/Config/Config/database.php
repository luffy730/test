<?php
return array(
    #读服务器
    'read'=>array(
    ),
    #写服务器
    'write'=>array(
    ),
    'host'              =>'127.0.0.1',   //主机
    'driver'            => 'mysql',     //数据库类型
    'charset'           => 'utf8',      //数据库字符集
    'user'              => 'root',      //数据库用户名
    'password'          => '',          //数据库密码
    'database'          => '',          //数据库名称
    'prefix'            => '',          //表前缀
);