<?php

//路由配置

Route::get('/','Home\Controller\IndexController@index');