<?php namespace Home\Controller; 
use Hdphp\Controller\Controller;
use QC;
//测试控制器
class IndexController extends Controller{

	//构造函数
	public function __init()
	{
	}
	
    //动作
    public function index(){
    		//如果是回调处理
    		if(Q('get.code') && Q('get.state')){
    			$qc = new QC();
			$acs = $qc->qq_callback();
			//返回每个用户的唯一的oid
			$oid = $qc->get_openid();
			$qc = new QC($acs,$oid);
			//得到qq返回的用户的信息
			$userInfo = $qc->get_user_info();
			//判断数据库是否有用户，如果没有就注册
			$userData = Db::table('user')->where("username='{$oid}'")->get();
			if(!$userData){
				$data = array(
					'username' => $oid,
					'nickname' => $userInfo['nickname'],
					'face'=>$userInfo['figureurl_1']
				);
				$uid = Db::table('user')->insert($data);
				$_SESSION['uid'] = $uid;
				$_SESSION['nickname'] = $userInfo['nickname'];
			}else{//用户已经存在了
				$_SESSION['uid'] = $userData[0]['uid'];
				$_SESSION['nickname'] = $userInfo['nickname'];
			}
			
			View::success('登陆成功',U('index'));
			
    		}

		
    		View::make();
    }
	
	/**
	 * 显示qq登陆的页面
	 */
	public function qqLogin(){
		$qc = new QC();
		$qc->qq_login();
	}
	
	public function logOut(){
		session_unset();
		session_destroy();
		View::success('退出成功');
	}
}
