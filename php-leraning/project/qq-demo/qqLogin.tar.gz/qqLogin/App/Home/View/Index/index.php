<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8" />
	<title>Document</title>
	<meta property="qc:admins" content="4540233607604521637571147716" />
</head>
<body>
	<?php if(isset($_SESSION['nickname'])): ?>
	欢迎 {{$_SESSION['nickname']}} 回来！ <a href="{{U('logOut')}}">退出</a>
	<?php endif ?>
	<hr />
	<a href="{{U('qqLogin')}}">QQ登陆</a>
</body>
</html>