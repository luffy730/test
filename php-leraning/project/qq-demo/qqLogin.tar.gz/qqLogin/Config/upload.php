<?php
return array(
	//允许上传类型
    'type'             		=> 'jpg,jpeg,gif,png,zip,rar,doc,txt',

    //允许上传文件大小 单位B
    'size'             		=> 2097152,   

    //上传路径
    'path'              	=> 'Upload',
);