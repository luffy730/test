<?php
return array(
	//开启Trace
	'trace'=>true,
	
	//Trace选项卡
	'level'=>array(
		'view'=>'视图',
		'sql'=>'sql语句',
		'file'=>'加载文件',
		'error'=>'错误',
		'debug'=>'调试'
		)
	);