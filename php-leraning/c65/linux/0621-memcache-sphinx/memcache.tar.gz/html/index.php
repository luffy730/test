<?php 
$m = new Memcache;
$m->connect('127.0.0.1',11211);
//设置缓存
$m->set('hdw','www.houdunwang.com',0,20);
//获取缓存
echo $m->get('hdw');


 ?>
